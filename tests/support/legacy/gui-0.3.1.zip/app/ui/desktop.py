"""Legacy GUI retained during CLI migration; no longer the primary entry point."""
import json
import os
from pathlib import Path
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

from app.application.tasks import TaskController
from app.application.workspaces import add_input, rename
from app.application.baselines import create_baseline
from app.infrastructure.persistence.store import Store
from app.application.run_history import latest_run
from app.infrastructure.process_runner.runner import Command, recover_interrupted, run


class Desktop:
    def __init__(self, root):
        self.root = root
        self.tasks = TaskController()
        self.store = None
        self.closing = False
        self.root.title('PS2 Workbench — Tahap 2 / Baseline ELF')
        self.root.geometry('920x680')
        self.root.minsize(680, 500)
        self.path = tk.StringVar()
        self.name = tk.StringVar(value='Proyek PS2')
        self.status = tk.StringVar(value='Buat atau buka workspace. Belum ada analisis ELF.')
        outer = ttk.Frame(root, padding=12)
        outer.pack(fill='both', expand=True)
        outer.columnconfigure(1, weight=1)
        ttk.Label(outer, text='Folder workspace').grid(row=0, column=0, sticky='w', padx=(0, 8))
        self.path_entry = ttk.Entry(outer, textvariable=self.path)
        self.path_entry.grid(row=0, column=1, sticky='ew')
        self.browse_button = ttk.Button(outer, text='Pilih folder…', command=self.browse)
        self.browse_button.grid(row=0, column=2, padx=(8, 0))
        ttk.Label(outer, text='Nama proyek').grid(row=1, column=0, sticky='w', pady=8)
        self.name_entry = ttk.Entry(outer, textvariable=self.name)
        self.name_entry.grid(row=1, column=1, sticky='ew')
        bar = ttk.Frame(outer)
        bar.grid(row=2, column=0, columnspan=3, sticky='ew', pady=(0, 8))
        self.buttons = []
        for text, callback in [('Buat baru', self.create), ('Buka', self.open),
                               ('Simpan nama', self.save), ('Daftarkan input…', self.input)]:
            button = ttk.Button(bar, text=text, command=callback)
            button.pack(side='left', padx=(0, 5))
            self.buttons.append(button)
        self.demo_button = ttk.Button(bar, text='Uji runner (sintetis)', command=self.demo)
        self.demo_button.pack(side='left', padx=(0, 5))
        self.cancel_button = ttk.Button(bar, text='Batalkan tugas', command=self.tasks.cancel, state='disabled')
        self.cancel_button.pack(side='left')
        ttk.Label(outer, text='Input tidak dijalankan. Baseline ELF tersedia; runner eksternal hanya POSIX.').grid(
            row=3, column=0, columnspan=3, sticky='w')
        book = ttk.Notebook(outer)
        book.grid(row=4, column=0, columnspan=3, sticky='nsew', pady=8)
        outer.rowconfigure(4, weight=1)
        workspace = ttk.Frame(book)
        logs = ttk.Frame(book)
        book.add(workspace, text='Workspace')
        book.add(logs, text='Log dan hasil run')
        baseline_tab = ttk.Frame(book)
        book.add(baseline_tab, text='Input / Baseline ELF')
        baseline_bar = ttk.Frame(baseline_tab, padding=5)
        baseline_bar.pack(fill='x')
        ttk.Label(baseline_bar, text='Input terdaftar:').pack(side='left')
        self.input_ids = []
        self.input_choice = ttk.Combobox(baseline_bar, state='readonly', width=40)
        self.input_choice.pack(side='left', fill='x', expand=True, padx=6)
        self.baseline_button = ttk.Button(baseline_bar, text='Periksa ELF / baseline', command=self.baseline)
        self.baseline_button.pack(side='left')
        self.baseline_text = ScrolledText(baseline_tab, wrap='word', state='disabled')
        self.baseline_text.pack(fill='both', expand=True)
        self.details = ScrolledText(workspace, wrap='word', state='disabled')
        self.details.pack(fill='both', expand=True)
        self.log = ScrolledText(logs, wrap='word', state='disabled')
        self.log.pack(fill='both', expand=True)
        self.history_button = ttk.Button(logs, text='Baca log run terakhir', command=self.history)
        self.history_button.pack(anchor='w', pady=5)
        ttk.Label(outer, textvariable=self.status, wraplength=850).grid(row=5, column=0, columnspan=3, sticky='w')
        self.root.protocol('WM_DELETE_WINDOW', self.close)
        self.path.trace_add('write', self.path_changed)
        self.refresh_controls()
        self.root.after(60, self.poll)

    def path_changed(self, *_):
        if self.store and self.path.get() != str(self.store.root):
            self.store = None
            self.input_ids = []
            self.input_choice.configure(values=[])
            self.input_choice.set('')
            self.text(self.baseline_text, 'Buka workspace baru untuk membaca input dan membuat baseline.')
            self.status.set('Path berubah. Buka workspace tersebut sebelum menyimpan atau menjalankan tugas.')
            self.refresh_controls()

    def text(self, widget, value, append=False):
        widget.configure(state='normal')
        if not append:
            widget.delete('1.0', 'end')
        widget.insert('end', value + '\n')
        # Bound UI memory independently of per-run file limits.
        if int(widget.index('end-1c').split('.')[0]) > 2500:
            widget.delete('1.0', '1000.0')
        widget.configure(state='disabled')
        widget.see('end')

    def refresh_controls(self):
        busy = self.tasks.busy or self.closing
        for b in self.buttons + [self.path_entry, self.name_entry, self.browse_button]:
            b.configure(state='disabled' if busy else 'normal')
        for b in self.buttons[2:] + [self.history_button]:
            b.configure(state='normal' if self.store and not busy else 'disabled')
        self.demo_button.configure(state='normal' if self.store and not busy and os.name == 'posix' else 'disabled')
        self.input_choice.configure(state='readonly' if self.store and not busy else 'disabled')
        self.baseline_button.configure(state='normal' if self.store and self.input_ids and not busy else 'disabled')

    def browse(self):
        path = filedialog.askdirectory(title='Pilih workspace yang sudah ada')
        if path:
            self.path.set(path)

    def start(self, operation, cancellable=False):
        self.tasks.submit(operation)
        self.status.set('Tugas berjalan…')
        self.refresh_controls()
        self.cancel_button.configure(state='normal' if cancellable else 'disabled')

    def create(self):
        path, name = self.path.get().strip(), self.name.get()
        if not path:
            messagebox.showerror('Path diperlukan', 'Ketik path folder workspace baru.')
            return
        def operation(cancel, emit):
            store = Store(path)
            return {'workspace': store.create(name).data, 'root': str(store.root)}
        self.start(operation)

    def open(self):
        path = self.path.get().strip()
        if not path:
            messagebox.showerror('Path diperlukan', 'Pilih folder workspace.')
            return
        def operation(cancel, emit):
            store = Store(path)
            data = store.load().data
            recovery = recover_interrupted(store)
            return {'workspace': data, 'root': str(store.root), 'interrupted_runs': recovery}
        self.start(operation)

    def save(self):
        store, name = self.store, self.name.get()
        self.start(lambda cancel, emit: {'workspace': rename(store, name).data, 'root': str(store.root)})

    def input(self):
        path = filedialog.askopenfilename(title='Pilih file untuk referensi dan hash (format belum divalidasi)')
        if path:
            store = self.store
            self.start(lambda cancel, emit: {'workspace': add_input(store, path).data, 'root': str(store.root)})

    def demo(self):
        # Explicit synthetic fixture, never claims to run Ghidra or analyze a game.
        command = Command((sys.executable, '-u', '-c',
                           "import time; print('Fixture sintetis: mulai', flush=True); time.sleep(5); print('Selesai')"), timeout=15)
        store = self.store
        self.start(lambda cancel, emit: {'run': run(store, command, cancel, emit)}, cancellable=True)

    def baseline(self):
        index = self.input_choice.current()
        if index < 0 or index >= len(self.input_ids):
            messagebox.showerror('Pilih input', 'Daftarkan file ELF dan pilih dari daftar input.')
            return
        store, input_id = self.store, self.input_ids[index]
        self.start(lambda cancel, emit: {'baseline_result': create_baseline(store, input_id, cancel, emit)}, cancellable=True)

    def history(self):
        store = self.store
        self.start(lambda cancel, emit: latest_run(store))

    def poll(self):
        for kind, payload in self.tasks.poll():
            if kind == 'event':
                self.text(self.log, json.dumps(payload, ensure_ascii=False), append=True)
            elif kind == 'error':
                self.status.set(payload['message'])
                self.text(self.log, json.dumps(payload, ensure_ascii=False), append=True)
            elif kind == 'done':
                if 'workspace' in payload:
                    self.store = Store(payload['root'])
                    self.path.set(payload['root'])
                    self.name.set(payload['workspace']['name'])
                    inputs = payload['workspace']['inputs']
                    self.input_ids = [item['id'] for item in inputs]
                    self.input_choice.configure(values=[item['id'][:8] + ' | ' + item['path'] for item in inputs])
                    if inputs:
                        self.input_choice.current(0)
                    else:
                        self.input_choice.set('')
                    self.text(self.details, json.dumps(payload, ensure_ascii=False, indent=2))
                    self.status.set('Workspace siap. Pilih input di tab Baseline ELF untuk pemeriksaan struktur.')
                elif 'baseline_result' in payload:
                    result = payload['baseline_result']
                    self.text(self.baseline_text, json.dumps(result, ensure_ascii=False, indent=2))
                    self.status.set('Baseline tersimpan: ' + result['report_file'])
                elif 'run' in payload:
                    self.text(self.log, json.dumps(payload['run'], ensure_ascii=False, indent=2), append=True)
                    self.status.set('Runner: ' + payload['run']['status'])
                else:
                    self.text(self.log, payload['history'])
                    self.status.set('Log aktual dimuat.')
            elif kind == 'idle':
                self.cancel_button.configure(state='disabled')
                self.refresh_controls()
        if self.closing and not self.tasks.busy:
            self.root.destroy()
            return
        self.root.after(60, self.poll)

    def close(self):
        if self.tasks.busy:
            self.closing = True
            self.tasks.cancel()
            self.status.set('Menunggu tugas selesai dan proses runner dibersihkan…')
            self.refresh_controls()
        else:
            self.root.destroy()


def main():
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        print(json.dumps({'error': 'display_unavailable', 'message': str(exc),
                          'hint': 'Jalankan pada desktop dengan Tk/display; CLI tetap tersedia.'}), file=sys.stderr)
        return 2
    Desktop(root)
    root.mainloop()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
