import json
import sys

try:
    from app.ui.desktop import main
except ModuleNotFoundError as exc:
    if exc.name not in ('tkinter', '_tkinter'):
        raise
    print(json.dumps({'error': 'tk_unavailable', 'message': 'Python ini tidak memiliki Tkinter; gunakan CLI atau instal Python dengan Tk.'}), file=sys.stderr)
    raise SystemExit(2)

raise SystemExit(main())
